export class Tree {
    id: string;
    name: string;
    path: string;
    type: string;
}