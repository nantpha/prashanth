import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Tree } from './git.model';

@Injectable()
export class TrackService {

    constructor(private http: HttpClient) {

    }

    getGitURLInfo(projectId: string, branch: string): Observable<Tree[]> {
        const fullUrl: string = `https://gitlab.prod.fedex.com/api/v4/projects/${projectId}/repository/tree?ref=${branch}`;
        const headers = new HttpHeaders()
            .append('Content-Type', 'application/json')
            .append('Access-Control-Allow-Headers', 'Content-Type')
            .append('Access-Control-Allow-Methods', 'GET')
            .append('Access-Control-Allow-Origin', '*')
            .append('PRIVATE-TOKEN', 'nh_utFkwj1pkK6Zm6Lus');
        return this.http.get<Tree[]>(fullUrl, { headers });
    }

    getFilesInsideFolder(projectId: string, branch: string, folder: string): Observable<Tree[]> {
        const fullUrl: string = `https://gitlab.prod.fedex.com/api/v4/projects/${projectId}/repository/tree?path=${folder}&ref=${branch}`;
        const headers = new HttpHeaders()
            .append('Content-Type', 'application/json')
            .append('Access-Control-Allow-Headers', 'Content-Type')
            .append('Access-Control-Allow-Methods', 'GET')
            .append('Access-Control-Allow-Origin', '*')
            .append('PRIVATE-TOKEN', 'nh_utFkwj1pkK6Zm6Lus');
        return this.http.get<Tree[]>(fullUrl, { headers });
    }

    getFileContent(projectId: string, branch: string, file: string): Observable<string> {
        const fullUrl: string = `https://gitlab.prod.fedex.com/api/v4/projects/${projectId}/repository/blobs/${file}/raw?ref=${branch}`;
        const headers = new HttpHeaders()
            .append('Content-Type', 'application/text')
            .append('Access-Control-Allow-Headers', 'Content-Type')
            .append('Access-Control-Allow-Methods', 'GET')
            .append('Access-Control-Allow-Origin', '*')
            .append('PRIVATE-TOKEN', 'nh_utFkwj1pkK6Zm6Lus');
        return this.http.get(fullUrl, { headers, responseType: "text" }
        );
    }
}