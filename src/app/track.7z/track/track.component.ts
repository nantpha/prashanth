import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
import { TrackService } from './track.service';
import { Tree } from './git.model';

@Component({
  selector: 'track',
  templateUrl: './track.component.html',
  styleUrls: ['./track.component.css']
})
export class TrackComponent implements OnInit {
  gitURL: string = '';
  gitBranch: string = '';

  gitURLInfo: Tree[];
  gitFolders: Tree[] = [];
  gitFiles: Tree[] = [];

  selectedFolder: string;
  fileContent: string;

  constructor(private dllService: TrackService) {

  }

  ngOnInit() {

  }

  getGitURLInfo(): void {
    this.dllService.getGitURLInfo(this.gitURL, this.gitBranch).subscribe(
      data => {
        this.gitURLInfo = data;
        if (this.gitURLInfo) {
          this.gitFolders = this.gitURLInfo.filter(tree => tree.type === "tree");
        }
      }
    );
  }

  onSelectFolder(event: any): void {
    this.selectedFolder = event.target.value;
    if (this.gitURLInfo && this.selectedFolder) {
      this.dllService.getFilesInsideFolder(this.gitURL, this.gitBranch, this.selectedFolder).subscribe(
        data => {
          if (data) {
            this.gitFiles = data.filter(tree => tree.type === "blob");
          }
        });
    }
  }

  onSelectFile(event: any): void {
    const file = event.target.value;
    this.dllService.getFileContent(this.gitURL, this.gitBranch, file).subscribe(
      data => this.fileContent = data
    );
  }
}
